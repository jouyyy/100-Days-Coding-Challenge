//variables: A B
//axiom: A
//rules: (A = AB), (B = A)

var axiom = "A";
var sentence = axiom;

var rules = [];
rules[0] = {
  a: "A",
  b: "AB"
  //b: "ABC"
  //Here is the rules could change 
}
rules[1] = {
  a: "B",
  b: "A"
}

function generate() {
  var nextSentence = "";
  //here is an empty string 
  for (var i = 0; i < sentence.length; i++) {
    var current = sentence.charAt(i);
    // this is the somthing do with strings in JavaScript and can look at ecah character one by one and pull it out
    var found = false;
    for (var j = 0; j < rules.length; j++) {
      if (current == rules[j].a) {
        found = true;
        nextSentence += rules[j].b;
        break;
      }
    }


    //if (current == rule1.a) {
    // nextSentence += rule1.b;
    //if current is a is rule1.a, put it in the rule1.b 
    // } else if (current == rule2.a) {
    //nextSentence += rule2.b;
    //if current is a is rule2.a, put it in the rule2.b 
    //} else {

    if (!found) {
      nextSentence += current;
      //if not any of the rules just keep current 
    }
  }


  sentence = nextSentence;
  //at the end of this sentence should be the actual current sentence is the next sentence
  createP(sentence);

}

function setup() {
  noCanvas();
  createP(axiom);
  //create P means creates a paragraph element in the page
  var button = createButton("generate");
  //create button is a function in the P5 Dom library
  button.mousePressed(generate);
}