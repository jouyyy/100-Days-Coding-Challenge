function Leaf() {
  this.pos = createVector(random(width), random(height - 100));
  //height get a random location that's about a hundred poxels off the bottom
  this.reached = false;

  
  this.show = function(){
    fill(50, 190, 204);
    noStroke();
    ellipse(this.pos.x, this.pos.y,4,4);
  
  }
}