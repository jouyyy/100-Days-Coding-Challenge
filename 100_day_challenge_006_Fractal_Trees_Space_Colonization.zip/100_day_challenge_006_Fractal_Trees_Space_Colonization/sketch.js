//From Coding Train: https://www.youtube.com/watch?v=kKT0v3qhIQY&list=PLRqwX-V7Uu6bxNsa_3SfCPyF9Md9XvXhR&index=4
// Code by Daniel Shiffman

var tree;
var max_dist = 100;
var min_dist = 10;
//max_dist and min_dist decide how the branch of the tree seens be.

function setup() {
  createCanvas(400, 400);
  tree = new Tree();
  //this line wasn't run, then check the index.html page. It works!!
}

function draw() {
  background(0);
  tree.show();
  tree.grow();
}