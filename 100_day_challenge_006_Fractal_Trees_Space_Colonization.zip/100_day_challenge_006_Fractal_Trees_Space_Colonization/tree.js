function Tree() {
  this.leaves = [];
  this.branches = [];

  for (var i = 0; i < 1500; i++) {
    //"i" means how many leaves on the backgroud.
    this.leaves.push(new Leaf());
  }
  var pos = createVector(width / 2, height);
  var dir = createVector(0, -1);
  var root = new Branch(null, pos, dir);
  //null means in kind of special case, it has no parent
  var record = 100000;
  this.branches.push(root);
  var current = root;
  var found = false;
  while (!found) {
    for (var i = 0; i < this.leaves.length; i++) {
      var d = p5.Vector.dist(current.pos, this.leaves[i].pos);
      if (d < max_dist) {
        found = true;
      }
    }


    if (!found) {
      var branch = current.next();
      current = branch;
      this.branches.push(current);
    }
  }




  this.grow = function() {
    //console.log ("growing")
    for (var i = 0; i < this.leaves.length; i++) {
      var leaf = this.leaves[i];
      var closestBranch = null;
      var record = max_dist;
      for (var j = 0; j < this.branches.length; j++) {
        var branch = this.branches[j];
        var d = p5.Vector.dist(leaf.pos, branch.pos);
        if (d < min_dist) {
          //if that distance is less than muniumum distance 
          leaf.reached = true;
          //leaves only exists to attract branches toward them, once the branch has reached a leaf that leaf is no longer in play.
          clsestBranch = null;
          break;
          //leaf is reached break.
        } else if (d > max_dist) {
          //else if distance is greater than max distance, this particular branch should be ignored.
        } else if (closestBranch == null || d < record) {
          //if closest branch is no, if it's not equal to no this should be checking if it's equal to no 
          closestBranch = branch;
          //the closest branch equals this particular branch. 
          record = d;
        }
      }
      
      
      if (closestBranch != null) {
        //make a new branch with a new direction
        var newDir = p5.Vector.sub(leaf.pos, closestBranch.pos);
        newDir.normalize();
        closestBranch.dir.add(newDir);
        //taking the existing branch and found the close the branch closest to that leaf, and got the direction. found the branch closest to that leaf, and found its direction and moving its direction toward.
         closestBranch.count++;
      }
    }
    //this part of algorithm: looking at every single leaf, if the leaf less than minimum distance from a branch, for every leaf look at every single branch. if its too close to a branch it done with that leaf. if it's too far away from the branch, that branch is not a condidate. If it actually is closest one it going to keep track of it and that branch is going to be attreacted to that particularly leaf. 

    for (var i = this.leaves.length - 1; i >= 0; i--) {
      if (this.leaves[i].reached) {
        this.leaves.splice(i, 1);
      }
    }

    for (var i = this.branches.length - 1; i >= 0 ; i--){
      var branch = this.branches[i];
      if(branch.count > 0){ 
        branch.dir.div(branch.count + 1);
        //the reason put + 1 due to: including the original direction the unit vector, add that unit vector with all the other unit vectors of close leaves. So there is one more there. 
        this.branches.push(branch.next());
//         var newPos = p5.Vector.add (branch.pos, branch.dir);
//         var newBranch = new Branch(branch, newPos, branch.dir.copy());
//         this.branches.push(newBranch);
        
      
      branch.reset();
    }
    }

    
  }


  this.show = function() {
    for (var i = 0; i < this.leaves.length; i++) {
      this.leaves[i].show();
    }

    for (var i = 0; i < this.branches.length; i++) {
      this.branches[i].show();
    }


  }


}