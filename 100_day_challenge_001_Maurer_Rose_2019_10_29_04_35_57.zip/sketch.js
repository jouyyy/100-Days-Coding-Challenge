let n = 6;
let d = 71;
let dSlider;
//let nSlider;

function setup() {
  createCanvas(600, 600);
  angleMode(DEGREES) 
  //most computer graphics systems treat angles in the unit measurement of radians by defauly, but in p5 allow say degrees
  dSlider = createSlider(1,180,1);
  //nSlider = createSlider(1,180,1);
  
}

function draw() {
  background(0);
  translate(width/2,height/2);
  stroke(182,228,226);
  d = dSlider.value();
  //n = nSlider.value();
  noFill();
  beginShape();
  strokeWeight(1);
  for (let i = 0; i < 360; i++) {
    let k = i * d;
    let r = 150*sin(n*k);
    let x = r * cos(k);
    let y = r * sin(k);
    vertex(x,y);
    
  }
  endShape();
   
  noFill();
  stroke(255);
  strokeWeight(4);
  beginShape();
  for (let i = 0; i < 361; i++) {
    let k = i;
    let r = 150*sin(n*k);
    let x = r * cos(k);
    let y = r * sin(k);
    vertex(x,y);
    
  }
  endShape();
  
}

