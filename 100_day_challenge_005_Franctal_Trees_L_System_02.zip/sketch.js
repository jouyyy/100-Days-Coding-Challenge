//variables:F+-[]
//axiom: F
//rules: F = FF+[+F-F-F]-[-F+F+F]

var angle;
var axiom = "F";
var sentence = axiom;
var len = 100;

var rules = [];
rules[0] = {
  a: "F",
  b: "FF+[+F-F-F]-[-F+F+F]"
}


function generate() {
  var nextSentence = "";
  //here is an empty string 
  for (var i = 0; i < sentence.length; i++) {
    var current = sentence.charAt(i);
    // this is the somthing do with strings in JavaScript and can look at ecah character one by one and pull it out
    var found = false;
    for (var j = 0; j < rules.length; j++) {
      if (current == rules[j].a) {
        found = true;
        nextSentence += rules[j].b;
        break;
      }
    }


    //if (current == rule1.a) {
    // nextSentence += rule1.b;
    //if current is a is rule1.a, put it in the rule1.b 
    // } else if (current == rule2.a) {
    //nextSentence += rule2.b;
    //if current is a is rule2.a, put it in the rule2.b 
    //} else {

    if (!found) {
      nextSentence += current;
      //if not any of the rules just keep current 
    }
  }


  sentence = nextSentence;
  //at the end of this sentence should be the actual current sentence is the next sentence
  createP(sentence);
  turtle();

}

function turtle() {
  len *= 0.6;
  //size of the len
  background(255);
  resetMatrix();
  //resetMatrix function is guarantees taht always stat the translations and rotations over again each time about to draw this L-system
  translate(width / 2, height);
  //at the beginning make sure 0,0 is the positioned at the bottom of the window 
  stroke(255, 111, 97, 100);
  //turtle graphics engine
  for (var i = 0; i < sentence.length; i++) {
    var current = sentence.charAt(i);

    if (current == "F") {
      line(0, 0, 0, -len);
      translate(0, -len);
    } else if (current == "+") {
      rotate(angle);
    } else if (current == "-") {
      rotate(-angle);
    } else if (current == "[") {
      push();
    } else if (current == "]") {
      pop();
    }
  }
}

function setup() {
  createCanvas(400, 400);
  angle = radians(25);
  background(255);
  createP(axiom);
  //create P means creates a paragraph element in the page
  turtle();
  var button = createButton("generate");
  //create button is a function in the P5 Dom library
  button.mousePressed(generate);
}