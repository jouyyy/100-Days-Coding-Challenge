var x;
var y;

function setup() {
  createCanvas(400, 400);
  x = 200;
  y = 200;
  background(0);
}

function draw() {

  stroke(0,180,170);
  strokeWeight(10);
  point(x, y);
  
  var r = floor(random(4));
  //floor() goes to lower number, cell() goes to higher number, round() gose to nearby number
  
  switch (r) {
  case 0:
   x = x +1;
  break;
  case 1:
   x = x - 1;
    break;
  case 2:
    y = y + 1;
    break;
  case 3:
    y = y - 1;
    break;
}
  //https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/switch
  
  
  
  
  
  
  
}