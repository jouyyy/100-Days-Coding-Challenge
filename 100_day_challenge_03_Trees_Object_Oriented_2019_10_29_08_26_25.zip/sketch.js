var tree = [];
var leaves = [];

var count = 0;

function setup() {
  createCanvas(400, 400);
  var a = createVector(width / 2, height);
  var b = createVector(width / 2, height - 100);
  var root = new Branch(a, b);

  tree[0] = root;

}

function mousePressed() {
  for (var i = tree.length - 1; i >= 0; i--) {
    //strat from the end of the array and go down to 0, which means going backwards throught the array and new things can get added to the end 
    if (!tree[i].finished) {
      tree.push(tree[i].branchA());
      tree.push(tree[i].branchB());
    }
    tree[i].finished = true;
  }
  count++;

  if (count === 6) {
    //give 5 branch that hasn't branches at the end, different level of the branch. eg. 5 is 5 times and 6 is 6 times
    for (var i = 0; i < tree.length; i++) {
      //for all of those last branches 
      if (!tree[i].finished) {
        var leaf = tree[i].end.copy();
        //make the leaf go and grab that end point of that branch and make a copy of it
        leaves.push(leaf);

      }
    }
  }
}


function draw() {
  background(51);

  for (var i = 0; i < tree.length; i++) {
    tree[i].show();
    //tree[i].jitter();
    //jitter function could made the tree shaking
  }

  for (var i = 0; i < leaves.length; i++) {
    fill(229, 109, 177, 200);
    noStroke();
    ellipse(leaves[i].x, leaves[i].y, 8, 8);
    leaves[i].y += random(0, 1);
    //random(speed)
  }
}