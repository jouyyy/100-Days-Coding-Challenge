//https://www.youtube.com/watch?v=KWoJgHFYWxY&list=PLRqwX-V7Uu6bxNsa_3SfCPyF9Md9XvXhR&index=9&t=332s

var n = 0;
var c = 6;
// c is the scaling factor, which means how much that radius changing 
var points = [];


function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES);
  colorMode(HSB);

}

function draw() {
  background(0);
  for (var i = 0; i < n; i++) {
    var a = i * 137.5;
    //angle decide the differnt patterns
    var r = c * sqrt(i);
    var x = r * cos(a) + width / 2;
    var y = r * sin(a) + height / 2;
    fill((a - r) % 170, 200, 150, 0.8);
    //fill(n % 255, 255, 100, 0.5 );
    //modulus is a way to cycle back to 0.
    noStroke();
    ellipse(x, y, 8, 8);
    //(x,y, n, n) "n" is decide the size of this ellipse
  }
  n++;

}