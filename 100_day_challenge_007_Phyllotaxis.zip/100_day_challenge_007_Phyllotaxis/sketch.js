//https://www.youtube.com/watch?v=KWoJgHFYWxY&list=PLRqwX-V7Uu6bxNsa_3SfCPyF9Md9XvXhR&index=9&t=332s

var n = 0;
var c = 4;
// c is the scaling factor, which means how much that radius changing 

function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES);
  colorMode(HSB);
  background(0);
}

function draw() {
  var a = n * 137.5;
  //angle decide the differnt patterns
  var r = c * sqrt(n);
  var x = r * cos(a) + width / 2;
  var y = r * sin(a) + height / 2;
  //fill((a - r) % 256, 255, 255);
  fill(0, n % 50, 168);
  //modulus is a way to cycle back to 0.

  noStroke();
  ellipse(x, y, 4, 4);
  //(x,y, n, n) "n" is decide the size of this ellipse
  n++;

}